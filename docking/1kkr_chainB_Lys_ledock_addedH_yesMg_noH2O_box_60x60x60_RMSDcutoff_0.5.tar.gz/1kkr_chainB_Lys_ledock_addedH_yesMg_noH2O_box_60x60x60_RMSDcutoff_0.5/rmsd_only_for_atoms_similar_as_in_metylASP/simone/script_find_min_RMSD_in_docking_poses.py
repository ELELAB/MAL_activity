#!/usr/bin/env python
import numpy as np
import sys

filename = sys.argv[1] 
k=int(raw_input("Number of the lowest values you want: "))


data=open(filename,"r")
lines=data.readlines()
data.close


RMSDpose=[]
RMSDvalues=[]
for i in range(0,len(lines)):
	print(i+1,lines[i].split())
        RMSDpose.append(i+1)
	RMSDvalues.append(lines[i].split()[3])

#print RMSDpose[0],RMSDpose[1]
#print RMSDvalues[0],RMSDvalues[1]

min_list = sorted(zip(RMSDpose,RMSDvalues), key=lambda t: t[1])[:k]

print "The docking poses with the ",k,"lowest values are:"
print "(in the form ('pose','value')"
print min_list
	
print "DONE."

