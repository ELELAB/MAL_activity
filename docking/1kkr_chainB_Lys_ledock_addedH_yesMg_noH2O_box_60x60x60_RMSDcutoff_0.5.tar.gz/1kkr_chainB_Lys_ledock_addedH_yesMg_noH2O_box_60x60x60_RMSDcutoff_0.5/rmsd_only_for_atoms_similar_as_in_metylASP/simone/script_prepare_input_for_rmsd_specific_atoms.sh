#!/bin/bash

name_pdb_file=Lysine_ZINC_1532522_docking_positions_
no_dock_poses=488


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C7  LIG /C7  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C8  LIG /C8  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C9  LIG /C9  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C15 LIG /C15 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O16 LIG /O16 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O17 LIG /O17 LIG1/g' ${name_pdb_file}${i}.pdb
done

