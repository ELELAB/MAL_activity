#!/usr/bin/env python

print "Short code to check how many of the distances are larger than certain value."
print "Select desired distance:\n1 K331.N--H\n2 Q329.N--O\n3 H194.N--O\n4 Mg--O"
k=int(raw_input("Which distance you want to check: "))
print "Select the cutoff distance"
dist=float(raw_input("Distance cutoff: "))


filename = "script_output_distances.dat"
data=open(filename,"r")
lines=data.readlines()
data.close
broj=0
for i in range(2,len(lines)-2):
        if float(lines[i].split()[k])>dist:
        	broj=broj+1

print "Number of distances larger than selected value:"
print broj
