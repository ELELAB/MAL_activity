#!/bin/bash

name_pdb_file=Aminoadipate_ZINC1532798_docking_positions_
no_dock_poses=426


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C7  LIG /C7  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C8  LIG /C8  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C9  LIG /C9  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C10 LIG /C10 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O11 LIG /O11 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O12 LIG /O12 LIG1/g' ${name_pdb_file}${i}.pdb
done
~       
