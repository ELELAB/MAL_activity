#!/bin/bash

name_pdb_file=Aminoadipate_ZINC1532798_docking_positions_
no_dock_poses=426


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C7  LIG /C7  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C8  LIG /C8  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C5  LIG /C5  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C13 LIG /C13 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O14 LIG /O14 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O15 LIG /O15 LIG1/g' ${name_pdb_file}${i}.pdb
done
~       
