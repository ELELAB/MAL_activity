
import math
import sys
import re
def calculateDistance(x1,y1,z1,x2,y2,z2):
     dist = math.sqrt((x2 - x1)**2 + (y2 - y1)**2+(z2 - z1)**2)
     return dist


#Coordinates of atoms in chainB-contansts
K331_N=[-17.132,-161.064,-79.020]
Q329_N=[-20.094,-163.867,-78.243]
H194_N=[-18.297,-162.736,-72.174]
Mg=[-16.831,-163.988,-76.258]

#print K331_N[0], K331_N[1], K331_N[2]
	
n=sys.argv[1]
print("Calculating distance for:", n)	#print out the filename we are currently processing
input = open(n, "r")
with open(n) as pdbdata:
	lines=pdbdata.readlines()
#print lines
input.close()

for i in range(len(lines)):
#        print len(lines)
	if sys.argv[2] in lines[i]:
		pose_H1x=lines[i].split()[5]
		pose_H1y=lines[i].split()[6]
		pose_H1z=lines[i].split()[7]
		

        if sys.argv[3] in lines[i]:
                pose_H2x=lines[i].split()[5]
                pose_H2y=lines[i].split()[6]
                pose_H2z=lines[i].split()[7]

        if sys.argv[4] in lines[i]:
                pose_O1x=lines[i].split()[5]
                pose_O1y=lines[i].split()[6]
                pose_O1z=lines[i].split()[7]
	if sys.argv[5] in lines[i]:
                pose_O2x=lines[i].split()[5]
                pose_O2y=lines[i].split()[6]
                pose_O2z=lines[i].split()[7]
#	else: print "There is no atom type you specified in the .pdb file"

#Calculate distance between N atom of K331, and 2x H atom in the pose which could be cataliticaly active, remember the lowest value
distance_K331_N_H1 = calculateDistance(K331_N[0],K331_N[1],K331_N[2],float(pose_H1x),float(pose_H1y),float(pose_H1z))
distance_K331_N_H2 = calculateDistance(K331_N[0],K331_N[1],K331_N[2],float(pose_H2x),float(pose_H2y),float(pose_H2z))
min_value_K331_N_poseH=min(distance_K331_N_H1,distance_K331_N_H2)
#print distance_K331_N_H10

#Calculate distance between N atom of Q329, and O atoms in the pose, remember lowest value
distance_Q329_N_O1 = calculateDistance(Q329_N[0],Q329_N[1],Q329_N[2],float(pose_O1x),float(pose_O1y),float(pose_O1z))
distance_Q329_N_O2 = calculateDistance(Q329_N[0],Q329_N[1],Q329_N[2],float(pose_O2x),float(pose_O2y),float(pose_O2z))
min_value_Q329_N_poseO=min(distance_Q329_N_O1,distance_Q329_N_O2)
#print distance_Q329_N_O1, distance_Q329_N_O2, min_value_Q329_N_poseO

#Calculate distance between N atom of H194, and O atoms in the pose, remember lowest value
distance_H194_N_O1 = calculateDistance(H194_N[0],H194_N[1],H194_N[2],float(pose_O1x),float(pose_O1y),float(pose_O1z))
distance_H194_N_O2 = calculateDistance(H194_N[0],H194_N[1],H194_N[2],float(pose_O2x),float(pose_O2y),float(pose_O2z))
min_value_H194_N_poseO=min(distance_H194_N_O1,distance_H194_N_O2)
#print distance_H194_N_O1, distance_H194_N_O2, min_value_H194_N_poseO

#Calculate distance between Mg atom, and O atoms in the pose, remember lowest value
distance_Mg_O1 = calculateDistance(Mg[0],Mg[1],Mg[2],float(pose_O1x),float(pose_O1y),float(pose_O1z))
distance_Mg_O2 = calculateDistance(Mg[0],Mg[1],Mg[2],float(pose_O2x),float(pose_O2y),float(pose_O2z))
min_value_Mg_poseO=min(distance_Mg_O1,distance_Mg_O2)
#print distance_Mg_O1, distance_Mg_O2, min_value_Mg_poseO

pose=re.findall("\d+",n)
#print pose[1]
f=open("script_output_distances.dat", "a+")
f.write("%d\t%f\t%f\t%f\t%f\n" %(int(pose[1]),min_value_K331_N_poseH ,min_value_Q329_N_poseO,min_value_H194_N_poseO,min_value_Mg_poseO))
f.close()
