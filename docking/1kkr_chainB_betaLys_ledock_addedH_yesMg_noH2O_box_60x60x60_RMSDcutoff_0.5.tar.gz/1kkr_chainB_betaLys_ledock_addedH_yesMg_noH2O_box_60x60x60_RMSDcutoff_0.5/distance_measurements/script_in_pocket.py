#Script to check which poses are inside the pocket. 
#Pocket is defined by 4 distances between cataliticaly important atoms
#If 3 or 4 these distances are bigger than certain trashold the pose is OUTSIDE the pocket.



filename='script_output_distances.dat'
input = open(filename, "r")
with open(filename) as pdbdata:
        lines=pdbdata.readlines()
#print lines
input.close()
poses=[]
poses_in_side_pocket=[]

for i in range(2,len(lines)):
	out_pocket=0
	in_pocket=0
	for j in range (1,5):
#		print ("i="+str(i)+"j="+str(j))
		if float(lines[i].split()[j]) > 4:
#			print ("First if: i="+str(i)+"j="+str(j))
			out_pocket=out_pocket+1
#			print out_pocket
		else:
#			print ("Else: i="+str(i)+"j="+str(j))
			in_pocket=in_pocket+1
#			print in_pocket
	if in_pocket>=3:
#		print ("in_pocket= "+str(in_pocket))
#		print ("lines[i].split()[1]="+str(lines[i].split()[0]))
		poses_in_side_pocket.append(lines[i].split()[0])

#print poses_in_side_pocket

print ("Number of poses in pocket: "+str(len(poses_in_side_pocket))+"\n"+"And they are:"+str(poses_in_side_pocket))
f=open("script_output_distances.dat", "a+")
f.write("Number of poses in pocket: "+str(len(poses_in_side_pocket))+"\n"+"And they are:"+str(poses_in_side_pocket))
f.close()
