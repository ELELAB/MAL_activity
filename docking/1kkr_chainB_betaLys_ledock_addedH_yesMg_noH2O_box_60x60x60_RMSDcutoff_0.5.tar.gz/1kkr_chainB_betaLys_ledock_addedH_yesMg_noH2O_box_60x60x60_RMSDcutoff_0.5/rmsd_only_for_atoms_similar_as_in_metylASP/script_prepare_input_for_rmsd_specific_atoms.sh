#!/bin/bash

name_pdb_file=betaLysine_ZINC_1532872_docking_positions_
no_dock_poses=484


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C7  LIG /C7  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C8  LIG /C8  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C14 LIG /C14 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C15 LIG /C15 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O16 LIG /O16 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O17 LIG /O17 LIG1/g' ${name_pdb_file}${i}.pdb
done
~       
