#!/bin/bash

name_pdb_file=Aminobutanoic.acid_ZINC168360924_docking_positions_
no_dock_poses=300


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C1  LIG /C1  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C2  LIG /C2  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C8  LIG /C8  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C9  LIG /C9  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O10 LIG /O10 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O11 LIG /O11 LIG1/g' ${name_pdb_file}${i}.pdb
done

