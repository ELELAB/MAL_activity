#!/bin/bash

name_pdb_file=betaGlutamic_acid_ZINC895793_docking_positions_
no_dock_poses=350


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C5  LIG /C5  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C6  LIG /C6  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C10 LIG /C10 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C11 LIG /C11 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O12 LIG /O12 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O13 LIG /O13 LIG1/g' ${name_pdb_file}${i}.pdb
done

