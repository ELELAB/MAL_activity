#!/bin/bash

name_pdb_file=betaGlutamic_acid_ZINC895793_docking_positions_

#To find out how many docking poses are there
shopt -s nullglob
for ext in pdb; do 
  files=( *."$ext" )
  printf 'number of %s files: %d\n' "$ext" "${#files[@]}"
done
no_dock_poses=${#files[@]}

#MIGHT NOT BE NEEDED IN GENERAL CASE!
#Formating poses was such that some columns got connected, this sepatates them.
###########
#WARNING!!# After this formating the chimera will not be able to open this file any more! So copy these files before doing this!
##########
for ((i=1; i <= ${no_dock_poses}; i++)); do
sed -i 's/-/ -/g' ${name_pdb_file}${i}.pdb
done

#Write headder of the new file where the distances would be
echo -e "Dist:\nPose:\tK331.N--H\tQ329.N--O\tH194.N--O\tMg--O" >> script_output_distances.dat


#Call the python script that will calculate distances between predefined atoms in protein(open python and change for your atoms)
#And between selected atoms from the poses:in this case H10, O16 and O17
echo Supply the names of the 4 atoms from the ligand for which you want to calculate distance, e.g. H10 H11 O15 O16 because of the symmery:
read atom1 atom2 atom3 atom4
for ((i=1; i <= ${no_dock_poses}; i++)); do
python script_distance.py ${name_pdb_file}${i}.pdb  $atom1 $atom2 $atom3 $atom4
done

#Call the python script that will define which poses are inside pocket, and which are outside.
python script_in_pocket.py

