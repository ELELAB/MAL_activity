#!/bin/bash

name_pdb_file=betaGlutamic_acid_ZINC895793_docking_positions_
no_dock_poses=350


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C5  LIG /C5  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C6  LIG /C6  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C7  LIG /C7  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C10 LIG /C10 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O8  LIG /O8  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O9  LIG /O9  LIG1/g' ${name_pdb_file}${i}.pdb
done

