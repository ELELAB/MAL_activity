#!/bin/bash

name_pdb_file=Aspartate_ZINC895032_docking_positions_
no_dock_poses=297


for ((i=1; i <= ${no_dock_poses}; i++)); do

sed -i 's/C5  LIG /C5  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C7  LIG /C7  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C8  LIG /C8  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/C11 LIG /C11 LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O9  LIG /O9  LIG1/g' ${name_pdb_file}${i}.pdb
sed -i 's/O10 LIG /O10 LIG1/g' ${name_pdb_file}${i}.pdb
done

