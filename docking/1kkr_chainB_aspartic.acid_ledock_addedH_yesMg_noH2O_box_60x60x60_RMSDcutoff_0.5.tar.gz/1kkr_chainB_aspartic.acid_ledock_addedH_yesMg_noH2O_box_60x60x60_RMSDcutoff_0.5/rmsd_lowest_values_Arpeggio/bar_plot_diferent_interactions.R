# name: string that specifies the name of output
# ligand: name of the ligand (I excluded it becuse they were not interested in calculating the number of its interactions)

get_specific_interaction <- function(my_data,name,ligand){
  install.packages("reshape")
  library(reshape)
  library(ggplot2)
  # remove the last column
  my_data$V18 <- NULL
  
  column1 <- data.frame(do.call('rbind', strsplit(as.character(my_data$V1),'/',fixed=TRUE)))
  column2 <- data.frame(do.call('rbind', strsplit(as.character(my_data$V2),'/',fixed=TRUE)))
  my_data$V1 <- apply(column1[,c(1,2)],1,paste,collapse = "/" )
  my_data$V2 <- apply(column2[,c(1,2)],1,paste,collapse = "/" )
  
  #get unique residues from both columns
  u1 <- unique(my_data$V1)
  u2 <- unique(my_data$V2)
  length(u1)
  length(u2)
  residues <- union(u1,u2)
  #remove ligand name from my residues of interest 
  #(not interested in calculating the number of its interactions) 
  residues <- residues[!residues %in% ligand]
  print(paste0("There are ",length(residues)," unique residues"))
  
  final_table <- c()
  for (i in 1:length(residues)) {
    
    new_data <- my_data[which(my_data$V1==residues[i] | my_data$V2==residues[i]),]
    inter <- c()
    for (j in 3:ncol(new_data)){
      
      inter <- append(inter,length(which(new_data[,j]==1)))
      
    }
    final_table <- rbind(final_table,inter)
  }
  colnames(final_table) <- c("Clash","Covalent", "VdW Clash","VdW",
                             "Proximal","Hydrogen Bond","Weak Hydrogen Bond","Halogen Bond",
                             "Ionic","Metal Complex"," Aromatic","Hydrophobic", "Carbonyl",
                             " Polar","Weak Polar")
  rownames(final_table) <- residues
  write.csv(final_table,file = paste0("specific_interactions_",name,".csv"))
  new_table <- melt(final_table)
  colnames(new_table) <- c("Residues","Interaction","Frequency")
  new_table <- new_table[-which(new_table$Frequency==0),]
  p <- ggplot(new_table, aes(x = Residues, y = Frequency)) +
    geom_bar(aes(fill = Interaction), stat="identity")
  
  ggsave(paste0("barplot_specificInteractions_",name,".pdf"), height = 9, width = 9)
  
  return(final_table)
}

############# example ###########
# read. file
my_data <- read.table("chainB+Aspartate_ZINC895032_docking_positions_renumbered_157_inter.contacts")
table <- get_specific_interaction(my_data,"inter_1","/1")